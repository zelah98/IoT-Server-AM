package com.example.sensehat;

public final class COMMON {
    // activities request codes
    public final static int REQUEST_CODE_CONFIG = 1;

    // configuration info: names and default values
    public final static String CONFIG_IP_ADDRESS = "ipAddress";
    public static String DEFAULT_IP_ADDRESS = "192.168.1.15";

    public final static String CONFIG_SAMPLE_TIME = "sampleTime";
    public static int DEFAULT_SAMPLE_TIME = 100;

    public final static String CONFIG_MAX_SAMPLES = "maxSamples";
    public static int DEFAULT_MAX_SAMPLES = 50;

    public final static String CONFIG_PORT_NUMBER = "portNumber";
    static String DEFAULT_PORT_NUMBER = "";



    // error codes
    public final static int ERROR_TIME_STAMP = -1;
    public final static int ERROR_NAN_DATA = -2;
    public final static int ERROR_RESPONSE = -3;


    // IoT server data
    public final static String FILE_NAME = "ServerScripts/chartdata.json";
    public final static String  FILE_LED= "ServerScripts/led_display.json";
    public final static String SERWER_LED="ServerScripts/led_display.php";

}